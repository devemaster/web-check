function getConfig() {
    return {
        name: "Site-Info"
    }
}

export default getConfig();